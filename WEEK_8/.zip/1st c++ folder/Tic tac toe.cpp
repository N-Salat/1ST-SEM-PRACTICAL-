#include <iostream>
using namespace std;

bool haswon(const char board[]) {
    return
        (board[0] == board[1] && board[1] == board[2]) ||
        (board[3] == board[4] && board[4] == board[5]) ||
        (board[6] == board[7] && board[7] == board[8]) ||
        (board[0] == board[3] && board[3] == board[6]) ||
        (board[1] == board[4] && board[4] == board[7]) ||
        (board[2] == board[5] && board[5] == board[8]) ||
        (board[0] == board[4] && board[4] == board[8]) ||
        (board[2] == board[4] && board[4] == board[6]);
}

int main() {
    char board[9] = {'1', '2', '3', '4', '5', '6', '7', '8', '9'};
    char currentPlayer = 'X';
    int position;

    for (int turn = 0; turn < 9; turn++) {
        cout << "\n " << board[0] << " | " << board[1] << " | " << board[2] << "\n";
        cout << "---+---+---\n";
        cout << " " << board[3] << " | " << board[4] << " | " << board[5] << "\n";
        cout << "---+---+---\n";
        cout << " " << board[6] << " | " << board[7] << " | " << board[8] << "\n";

        cout << "Player " << currentPlayer << ", choose a position: ";
        cin >> position;

        if (position < 1 || position > 9) {
            cout << "Choose a number from 1 to 9.\n";
            turn--;
            continue;
        }

        if (board[position - 1] == 'X' || board[position - 1] == 'O') {
            cout << "That position is already taken.\n";
            turn--;
            continue;
        }

        board[position - 1] = currentPlayer;

        if (haswon(board)) {
            cout << "Player " << currentPlayer << " wins!\n";
            break;
        }

        if (currentPlayer == 'X') {
            currentPlayer = 'O';
        } else {
            currentPlayer = 'X';
        }
    }

    for (int turn = 0;turn < 9; turn++) {
        if(haswon(board)){
            cout << "player" << currentPlayer << "wins/n";
            break;
        }
        if (turn == 8) {
            cout << "\nIt's a draw!!\n";
            break;
        }
        

    }
}