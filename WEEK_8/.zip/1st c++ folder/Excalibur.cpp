#include <iostream>
using namespace std;
#include <string>
string name;
int age;

int main() {


cout << " Hello!!!" << endl;
cout << " Welcome to Avalor" << endl;
do {
    cout << " What is your name? ";
    getline(cin, name);

    if (name.empty() || name.find_first_not_of(" \t") == string::npos) {
        cout << " I will need your name for this adventure to continue!!!" << endl;
    }
} while (name.empty() || name.find_first_not_of(" \t") == string::npos);

cout << " Aaaahh so you're " << name << endl;

cout << " How old are you " << name <<endl;
cin >> age;
cout << "So you're " << age << " years old " << name   << endl;


}